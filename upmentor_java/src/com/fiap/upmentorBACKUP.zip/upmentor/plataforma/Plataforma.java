package com.fiap.upmentor.plataforma;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

import com.fiap.upmentor.cursos.Curso;
import com.fiap.upmentor.usuarios.Gestor;
import com.fiap.upmentor.usuarios.Liderado;

public class Plataforma {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		List<Gestor> gestores = new ArrayList<>();
		List<Liderado> liderados = new ArrayList<>();
		List<Curso> cursos = new ArrayList<>();

		boolean executando = true;

		while (executando) {
			System.out.println("\n========= MENU PRINCIPAL =========");
			System.out.println("1 - Cadastrar Gestor");
			System.out.println("2 - Cadastrar Liderado");
			System.out.println("3 - Cadastrar Curso");
			System.out.println("4 - Atribuir Liderado ao Gestor");
			System.out.println("5 - Atribuir Curso");
			System.out.println("6 - Exibir informações");
			System.out.println("0 - Sair");
			System.out.print("Escolha uma opção: ");

			int opcao = lerInteiro(sc);

			switch (opcao) {
			case 1 -> {
				System.out.print("Nome do gestor: ");
				String nomeGestor = sc.nextLine();
				Gestor gestor = new Gestor(nomeGestor);
				gestores.add(gestor);
				System.out.print("Gestor cadastrado com sucesso!");
			}

			case 2 -> {
				System.out.print("Nome do liderado: ");
				String nomeLiderado = sc.nextLine();

				System.out.print("\n");

				System.out.print("Codigo do liderado: ");
				String codigoLiderado = sc.nextLine();

				System.out.print("\n");

				Liderado liderado = new Liderado(nomeLiderado, codigoLiderado);
				liderados.add(liderado);
				System.out.println("Liderado cadastrado com sucesso!");
			}

			case 3 -> {
				System.out.print("Nome do curso: ");
				String nomeCurso = sc.nextLine();

				System.out.print("Código do curso: ");
				String codigo = sc.nextLine();

				System.out.print("Quantas aulas o curso terá? ");
				int qtdAulas = lerInteiro(sc);

				String[] aulas = new String[qtdAulas];
				for (int i = 0; i < qtdAulas; i++) {
					System.out.print("Nome da aula " + (i + 1) + ": ");
					aulas[i] = sc.nextLine();
				}

				Curso curso = new Curso(aulas, codigo, nomeCurso);
				cursos.add(curso);
				System.out.println("Curso cadastrado com sucesso!");
			}

			case 4 -> {
				if (gestores.isEmpty() || liderados.isEmpty()) {
					System.out.println("Cadastre pelo menos um gestor e um liderado antes!");
					break;
				}

				System.out.println("Selecione o gestor:");
				listarGestores(gestores);
				int idxGestor = lerInteiro(sc) - 1;
				if (!indiceValido(idxGestor, gestores.size()))
					break;

				Gestor gestor = gestores.get(idxGestor);

				System.out.println("Selecione o liderado:");

				listarLiderados(liderados);
				int idxLiderado = lerInteiro(sc) - 1;
				if (!indiceValido(idxLiderado, liderados.size()))
					break;

				Liderado liderado = liderados.get(idxLiderado);
				gestor.atribuirLiderado(liderado);

				System.out.println("Gestor atribuído com sucesso!");
			}

			case 5 -> {
				if (gestores.isEmpty() || liderados.isEmpty() || cursos.isEmpty()) {
					System.out.println("Cadastre pelo menos um gestor, um liderado e um curso antes!");
					break;
				}

				System.out.println("Selecione o gestor:");
				listarGestores(gestores);
				int idxGestor = lerInteiro(sc) - 1;
				if (!indiceValido(idxGestor, gestores.size()))
					break;

				Gestor gestor = gestores.get(idxGestor);

				if (gestor.getLiderados().isEmpty()) {
					System.out.println("Gestor sem liderados atribuidos!");
					break;
				}

				gestor.exibirLiderados();

				System.out.print("Escolha uma opção: \n");
				int opcaoLiderado = lerInteiro(sc);

				Liderado tempLiderado = liderados.get(opcaoLiderado - 1);

				System.out.println("Selecione o curso:");
				listarCursos(cursos);
				int idxCurso = lerInteiro(sc) - 1;
				if (!indiceValido(idxCurso, cursos.size()))
					break;

				Curso curso = cursos.get(idxCurso);
				gestor.atribuirCurso(curso, tempLiderado);

				System.out.println("Curso atribuído com sucesso!");
			}

			case 6 -> {
				while (true) {
					System.out.println("\n--- Selecione um Gestor ---");
					listarGestores(gestores);
					System.out.println("0 - Voltar\n");
					System.out.print("Escolha uma opção: \n");

					int opcaoGestor = lerInteiro(sc);

					if (opcaoGestor == 0) {
						break;
					}

					Gestor tempGestor = gestores.get(opcaoGestor - 1);

					while (true) {
						tempGestor.exibirLiderados();
						System.out.println("0 - Voltar\n");

						System.out.print("Escolha uma opção: \n");
						int opcaoLiderado = lerInteiro(sc);

						if (opcaoLiderado == 0) {
							break;
						}

						Liderado tempLiderado = liderados.get(opcaoLiderado - 1);

						while (true) {
							tempLiderado.exibirCursos();
							System.out.println("0 - Voltar\n");

							System.out.print("Escolha uma opção: \n");
							int opcaoCurso = lerInteiro(sc);

							if (opcaoCurso == 0) {
								break;
							}

							System.out.println("");

							boolean opcaoCursoFlag = true;

							while (opcaoCursoFlag) {
								System.out.println("\\n========= AÇÕES DO CURSO =========\\");
								System.out.println("1 - Assistir aula");
								System.out.println("2 - Completar curso");
								System.out.println("0 - Voltar");
								System.out.print("Escolha uma opção: ");
								int acaoCurso = lerInteiro(sc);

								String codigoCursoTemp = tempLiderado.getCursos().get(opcaoCurso - 1).getCodigo();

								switch (acaoCurso) {
								case 1 -> {
									tempLiderado.assistirAula(codigoCursoTemp);
								}
								case 2 -> {
									tempLiderado.concluirCurso(codigoCursoTemp);
									opcaoCursoFlag = false;
								}
								case 0 -> {
									opcaoCursoFlag = false;
								}
								}
							}
						}

					}

				}

			}

			case 0 -> {
				System.out.println("Encerrando o sistema...");
				executando = false;
			}

			default -> System.out.println("Opção inválida. Tente novamente!");
			}
		}

		sc.close();
	}

	private static int lerInteiro(Scanner sc) {
		while (true) {
			try {
				int valor = Integer.parseInt(sc.nextLine());
				return valor;
			} catch (NumberFormatException e) {
				System.out.print("Entrada inválida! Digite um número inteiro: ");
			}
		}
	}

	private static boolean indiceValido(int indice, int tamanho) {
		if (indice < 0 || indice >= tamanho) {
			System.out.println("Índice inválido!");
			return false;
		}
		return true;
	}

	private static void listarGestores(List<Gestor> gestores) {
		for (int i = 0; i < gestores.size(); i++) {
			System.out.println((i + 1) + " - " + gestores.get(i).getNome());
		}
	}

	private static void listarLiderados(List<Liderado> liderados) {
		for (int i = 0; i < liderados.size(); i++) {
			System.out.println((i + 1) + " - " + liderados.get(i).getNome());
		}
	}

	private static void listarCursos(List<Curso> cursos) {
		for (int i = 0; i < cursos.size(); i++) {
			System.out.println((i + 1) + " - " + cursos.get(i).getTitulo());
		}
	}
}
