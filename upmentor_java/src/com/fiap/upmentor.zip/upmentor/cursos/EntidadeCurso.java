package com.fiap.upmentor.cursos;

public class EntidadeCurso {
	String codigo;
	String titulo;
}
