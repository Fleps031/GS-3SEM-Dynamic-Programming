package com.fiap.upmentor.plataforma;

public class TesteSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
